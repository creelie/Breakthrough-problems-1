# Submission checklist: European Journal of Combinatorics

Journal: *European Journal of Combinatorics* (Elsevier), which publishes work on tournaments,
Hamilton cycles and algebraic methods in combinatorics. Submission through Elsevier's Editorial
Manager, linked from https://www.sciencedirect.com/journal/european-journal-of-combinatorics.
Fallbacks: *Random Structures & Algorithms*; *Combinatorics, Probability and Computing*; *The
Electronic Journal of Combinatorics*.

Files to upload:

1. `ejc-manuscript-final2.pdf`: the manuscript in Elsevier's class `elsarticle` (15 pages).
2. `ejc-manuscript-source-final2.zip`: `main.tex` and the two PNG figures; it compiles with
   `pdflatex main.tex` (three runs) on any TeX Live with `elsarticle`.
3. `cover-letter.md`: paste into the cover-letter field.

Metadata to enter:

- Title: Two conjectures of Wormald on Hamilton cycles in tournaments
- Article type: Research paper
- Author: Deep Bhattacharjee (sole author, corresponding), ORCID 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar,
  Odisha 751030, India
- Keywords: tournament; Hamilton cycle; random blow-up; Hessian determinant; skew-symmetric matrix;
  formal verification
- MSC 2020: 05C20, 05C45 (primary); 05C50, 05C80, 15A15 (secondary)

Only the author can confirm:

- [ ] "This research did not receive any specific grant ..." (stated under Funding)
- [ ] "The author has no competing interests to declare." (stated under Declaration of competing
      interest)
- [ ] postal address and telephone number, if the system asks for them
- [ ] suggested referees, if the system asks (people who work on Hamilton cycles in tournaments or
      random tournaments and are not coauthors of the author)

Before submitting, optionally post the arXiv tarball (`dist/wormald-tournaments_final2-arxiv.tar.gz`
in the repository folder) to arXiv (math.CO); the journal does not require it.
