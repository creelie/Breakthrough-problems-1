# Cover letter

To the Editors of the *European Journal of Combinatorics*

Dear Editors,

I submit the manuscript "Two conjectures of Wormald on Hamilton cycles in tournaments" for
consideration.

N. C. Wormald (*Tournaments with many Hamilton cycles*, arXiv:2610.16245) lower-bounded the
largest number h(n) of Hamilton cycles in an n-vertex tournament by averaging over random blow-ups
of a fixed regular tournament. The expected number is governed by the determinant H of the Hessian
of an implicit function, which he evaluated by computer algebra. He conjectured that d/H is always
the square of a rational number (his Conjecture 6), that the constants attached to the cyclic
tournaments converge (his Conjecture 2), and, from polynomial fits, that the limit is about
2.855958.

The manuscript proves both conjectures by computing H in closed form: for a regular tournament on
d vertices with skew adjacency matrix S, H = d det(d²I + S²)/det(d²I − S²), and √(d/H) is the ratio
of the integers det(dI − S) and det(dI − iS). For the cyclic tournament this gives
√(d/H) = ((d+1)^d + (d−1)^d)/((d+i)^d + (d−i)^d), so the limit is cosh 1/cos 1, and the expansion
in 1/d explains the vanishing coefficients that Wormald observed in his fits. The paper also bounds
the constant over all regular tournaments: the lower bound is attained exactly by the doubly
regular ones, and the upper bound tends to a limit only 0.051% above cosh 1/cos 1. It also
corrects two numbers in Wormald's text.

The algebraic part is formalised in Lean 4 with Mathlib, and every number in the paper is
recomputed by programs that are publicly available with the formalization.

The manuscript is not under consideration elsewhere. I declare no competing interests and no
funding.

Yours sincerely,

Deep Bhattacharjee
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
d.bhattacharjee@erl-forschung.de, itsdeep@live.com, ORCID 0000-0003-0466-750X
