# Master zip: two conjectures of Wormald on Hamilton cycles in tournaments

Deep Bhattacharjee, ORCID 0000-0003-0466-750X. Built 14 October 2026.

Proofs of Conjectures 2 and 6 of N. C. Wormald, *Tournaments with many Hamilton cycles*
(arXiv:2610.16245). For a regular tournament on d vertices with skew adjacency matrix S,
H = d det(d²I + S²)/det(d²I − S²), so H ≠ 0 and d/H is a rational square; for the cyclic
tournament the constants tend to cosh 1/cos 1 = 2.8559578925…

Repository: https://github.com/creelie/Breakthrough-problems-1
Release v1.0.0: https://github.com/creelie/Breakthrough-problems-1/releases/tag/v1.0.0

## Contents

- `journal-EuropeanJCombin/`: the manuscript in Elsevier's `elsarticle` class for the *European
  Journal of Combinatorics* (PDF and LaTeX source with PNG figures), a cover letter, and a checklist
  of what only the author can confirm (funding and competing-interest statements, address,
  referees).
- `repository/`: a snapshot of the repository at the release, with the amsart paper and its
  arXiv tarball in `dist/`, the Lean 4 proof, and the C, Python and PARI/GP checks.
- `PRIORITY-CHECK.md`: the dated check, 14 October 2026, that nobody had settled the conjectures.

## What is open or not formalized

Both conjectures are proved in full in the paper. The Lean formalization covers the algebra and
both conjectures with H taken as det(EᵀFE); the identification of Wormald's analytic H with
det(EᵀFE) (Proposition 3.1, implicit function theorem), the asymptotic expansion and the bounds of
Theorem 1.5 are paper proofs checked by exact computation, not formalized. Wormald's Conjecture 1
(R_d maximizes the constant among all tournaments) and his Conjecture 5 (h(n) ~ c g(n) with
c = cosh 1/cos 1) remain open; the paper shows only lim sup h(n)/g(n) ≥ cosh 1/cos 1.
